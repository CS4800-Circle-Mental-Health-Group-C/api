# Latest and Final Release
Release 1.0

# Features 
- Create, Get, Update, and Delete a User and their Circle members
- Create, Get, Update, and Delete a User's survey
- Create, Get, Update, and Delete Surveys to be presented to the user.

# Bugs
No known bugs at this time

# Notes
API is open and does not require authorization.
